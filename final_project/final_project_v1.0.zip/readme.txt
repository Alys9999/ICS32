Zhaoyang Lu
30735594
ICS 32


before the change of account, you should be offline

the server function has only the window and renew info, the actual test for changing the ip is not down due to there is no other ip to chooose.(deleted)

the program can ask for the messages from server and make them into friends chat: messages pair and assign them corespondingly. 
Add friend button for adding a new friend. 
The send button can send messges in the input box to the friend selected in the friend_tree.
 All refresh of messages happens when clicking of online button or adding of new friend

The main codes are based on my a4.
I did all the coding work.


latest update 27/June/2021